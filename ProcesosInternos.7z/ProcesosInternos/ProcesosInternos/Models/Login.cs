﻿using System.ComponentModel.DataAnnotations;

namespace ProcesosInternos.Models
{
    public class Login
    {
        [Display(Name = "Usuario")]
        public string usuario { get; set; }

        [Display(Name = "Contraseña")]
        public string password { get; set; }

    }
}
