﻿$(document).ready(function () {
    (function (plugin) {
        function init(message) {
            if (message != "null") {
                var MessageResponse = JSON.parse(message);
                if (MessageResponse !== null) {
                    alerta(MessageResponse.Mensaje);
                }
            }
        }
        plugin.init = init;
    })(APP);

    localStorage.setItem("path", '');
    var formLogin = document.getElementById("frmAcceso");

    //$("#btnLogin").on("click", function () {
    //    formLogin.submit();
       
    //});

});
var APP = {};