﻿//(function () {
//    'use strict'


//    var forms = document.querySelectorAll('.needs-validation')

//     Array.prototype.slice.call(forms)
//        .forEach(function (form) {
//            form.addEventListener('submit', function (event) {
//                if (!form.checkValidity()) {
//                    event.preventDefault()
//                    event.stopPropagation()
//                }

//                form.classList.add('was-validated')
//            }, false)
//        })
//})()


const togglePassword = document.querySelector("#togglePassword");
const password = document.querySelector("#password");

togglePassword.addEventListener("click", function () {
    // toggle the type attribute
    const type = password.getAttribute("type") === "password" ? "text" : "password";
    password.setAttribute("type", type);

    // toggle the icon
    this.classList.toggle("bi-eye");
});


const form = document.querySelector("Inicio");
form.addEventListener('submit', function (e) {
    e.preventDefault();
});